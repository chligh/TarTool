#pragma once
 
class ILogServer
{
public:
	virtual void log(const char * pszFormat, ...) = 0;
	virtual void logLastLine(const char *lpszText, const char * pszFormat, ...) = 0;
};


class CLogServer: public ILogServer
{
public:
	CLogServer();
	virtual void log(const char * pszFormat, ...);
	virtual void logLastLine(const char *lpszText, const char * pszFormat, ...);
	void setWnd(CWnd *pWnd);

private:
	CWnd		*m_pWnd;
};


extern ILogServer  *g_pLogServer;
