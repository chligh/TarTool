#pragma once
 
#include <string>
#include <vector>

void split_str_by_char(const std::string &in_str, const char *delim, std::vector<std::string> &str_list, 
	bool ignore_repeat_delim, bool split_once = false, int nSkipLen = 1);
