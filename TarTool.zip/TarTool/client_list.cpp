#include <iostream>
#include <vector>
#include <string>
#include "client_list.h"
#include "windows.h"
#include "md5.h"

bool CClientList::save_list(char * lpszFile, const char *lpszResPath)
{
	FILE *fp = fopen(lpszFile, "wb+");
	if (fp != NULL)
	{
		char *lpszBegin = "{";
		fwrite(lpszBegin, strlen(lpszBegin), 1, fp);

		find(fp, lpszResPath);

		char *lpszEnd = "\r\n}";
		fwrite(lpszEnd, strlen(lpszEnd), 1, fp);
		fclose(fp);
	}
	return true;
}

void CClientList::find(FILE *fp, const char * lpPath)
{
	char szFind[MAX_PATH];
	WIN32_FIND_DATA FindFileData;
	strcpy(szFind,lpPath);
	strcat(szFind,"\\*.*");

	HANDLE hFind = ::FindFirstFile(szFind, &FindFileData);
	if(INVALID_HANDLE_VALUE == hFind)
	{
		return;
	}

	static int ii = 0;
	while(TRUE)
	{
		if(FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		{
			if(FindFileData.cFileName[0]!='.')
			{
/*				strcpy(szFile,lpPath);
				strcat(szFile,"");
				strcat(szFile,FindFileData.cFileName);
				find(szFile);*/
			}
		}
		else
		{
			std::string strFile = lpPath;
			strFile = strFile + FindFileData.cFileName;

			FILE *fRead = fopen(strFile.c_str(), "rb+");
			fseek(fRead, 0, SEEK_END);
			int nLen = ftell(fRead);
			fseek(fRead, 0, SEEK_SET);
			void *pData = new unsigned char [nLen];
			fread(pData, nLen, 1, fRead);

			MD5  stMD5;
			stMD5.update((const char *)pData, nLen);
			stMD5.finalize();
			std::string strResult = stMD5.hexdigest();

			std::string strPrefix = "\r\n";
			if (ii++ != 0)
			{
				strPrefix = ",\r\n";
			}
			strPrefix = strPrefix + "  \"" + FindFileData.cFileName + "\":\"";

			fwrite(strPrefix.c_str(), strPrefix.length(), 1, fp);
			fwrite(strResult.c_str(), strResult.length(), 1, fp);
			fwrite("\"", 1, 1, fp);
			fclose(fRead);
		}
		if(!FindNextFile(hFind,&FindFileData))
		{
			break;
		}
	}
	FindClose(hFind);
}
