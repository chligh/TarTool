#pragma once

#include "stdio.h"

class CClientList
{
public:
	CClientList(){}
	~CClientList(){}
	bool save_list(char * lpszFile, const char *lpszResPath);
private:

	void find(FILE *fp, const char * lpPath);
};