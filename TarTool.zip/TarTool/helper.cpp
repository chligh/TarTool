 
#include "helper.h"
 
void split_str_by_char(const std::string &in_str, const char *delim, std::vector<std::string> &str_list, 
	bool ignore_repeat_delim, bool split_once/* = false*/, int nSkipLen /*= 1*/)
{
	if (in_str.empty())
	{
		return;
	}

	std::string::size_type head = 0, tail = 0;
	while (true)
	{
		tail = in_str.find(delim, head);
		if (head == tail && ignore_repeat_delim)
		{
			++head;
			continue;
		}

		if (tail == std::string::npos)
		{
			str_list.push_back(in_str.substr(head));
			break;
		}
		else
		{
			str_list.push_back(in_str.substr(head, tail - head));
			head = tail + nSkipLen;

			if (true == split_once)
			{
				str_list.push_back(in_str.substr(head, tail - head));
				break;
			}
		}
	}
}

