 #include "stdafx.h"
#include <iostream>
#include <vector>
#include <string>
#include <map>
#include "windows.h"
#include "simple_encode.h"
#include "md5.h"
#include "crc32.h"
#include "ILog.h"

CSimpleEncode::CSimpleEncode()
{
}

CSimpleEncode::~CSimpleEncode()
{
}


//�����ַ��������
char EncodeChar(char c,int key)
{
	return c=c^key;
}
//�����ַ�����
char DecodeChar(char c,int key)
{
	return c^key;
}

//����
void Encode(char *pstr, int nSrcLen, int *pkey, int nKeyLen)
{
	for(int i=0; i < nSrcLen; ++i)
	{
		*(pstr+i)=EncodeChar(*(pstr+i), pkey[i % nKeyLen]);
	}
}

//����
void Decode(char *pstr, int nSrcLen, int *pkey, int nKeyLen)
{
	for(int i=0; i<nSrcLen; ++i)
	{
		*(pstr+i)=DecodeChar(*(pstr+i),pkey[i % nKeyLen]);
	}
}


bool CSimpleEncode::initialize(const char * lpszResPath, const char *lpszSavedPath)
{
	char szFind[MAX_PATH];
	WIN32_FIND_DATA FindFileData;
	strcpy(szFind, lpszResPath);
	strcat(szFind,"*.*");

	HANDLE hFind = ::FindFirstFile(szFind, &FindFileData);
	if(INVALID_HANDLE_VALUE == hFind)
	{
		return false;
	}
#define KEYS_COUNT  9
	int nKeys[KEYS_COUNT] = {1, 2, 3, 6, 7, 8, 5, 9, 0};
	int nKeyLen = KEYS_COUNT;

	while(TRUE)
	{
		if(FindFileData.dwFileAttributes &FILE_ATTRIBUTE_DIRECTORY)
		{
			if(FindFileData.cFileName[0]!='.')
			{
				// �ݲ�������Ŀ¼
			}
		}
		else
		{
			std::string strFile = lpszResPath;
			strFile = strFile + FindFileData.cFileName;

			FILE *fRead = fopen(strFile.c_str(), "rb+");
			fseek(fRead, 0, SEEK_END);
			int nLen = ftell(fRead);
			fseek(fRead, 0, SEEK_SET);

			unsigned char *pBuffer = new unsigned char [nLen];
			fread(pBuffer, nLen, 1, fRead);

			strFile = lpszSavedPath;
			strFile = strFile + FindFileData.cFileName + "z";
			FILE *fSave = fopen(strFile.c_str(), "wb+");
			if (fSave != NULL)
			{
				Encode((char*)pBuffer, nLen, nKeys, nKeyLen);
				fwrite(pBuffer, nLen, 1, fSave);
				fclose(fSave);
			}

			fclose(fRead);
		}
		if(!FindNextFile(hFind,&FindFileData))
		{
			break;
		}
	}
	FindClose(hFind);
	return true;
}

void CSimpleEncode::decodeFile(const char * lpszResPath)
{
	char szFind[MAX_PATH];
	WIN32_FIND_DATA FindFileData;
	strcpy(szFind, lpszResPath);
	strcat(szFind,"*.*");

	HANDLE hFind = ::FindFirstFile(szFind, &FindFileData);
	if(INVALID_HANDLE_VALUE == hFind)
	{
		return ;
	}
#define KEYS_COUNT  9
	int nKeys[KEYS_COUNT] = {1, 2, 3, 6, 7, 8, 5, 9, 0};
	int nKeyLen = KEYS_COUNT;

	while(TRUE)
	{
		if(FindFileData.dwFileAttributes &FILE_ATTRIBUTE_DIRECTORY)
		{
			if(FindFileData.cFileName[0]!='.')
			{
				// �ݲ�������Ŀ¼
			}
		}
		else
		{
			std::string strFile = lpszResPath;
			strFile = strFile + FindFileData.cFileName;

			FILE *fRead = fopen(strFile.c_str(), "rb+");
			fseek(fRead, 0, SEEK_END);
			int nLen = ftell(fRead);
			fseek(fRead, 0, SEEK_SET);

			unsigned char *pBuffer = new unsigned char [nLen];
			fread(pBuffer, nLen, 1, fRead);


			CString strDstFile = strFile.c_str();
			int nLength = strDstFile.GetLength();
			strDstFile = strDstFile.Left(nLength - 1);
			FILE *fSave = fopen(strDstFile, "wb+");
			if (fSave != NULL)
			{
				Decode((char*)pBuffer, nLen, nKeys, nKeyLen);
				fwrite(pBuffer, nLen, 1, fSave);
				fclose(fSave);
			}

			fclose(fRead);
		}
		if(!FindNextFile(hFind,&FindFileData))
		{
			break;
		}
	}
	FindClose(hFind);
	return ;
}



