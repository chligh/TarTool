#include "stdafx.h"
#include "ILog.h"
#include "Resource.h"
#include "TarToolDlg.h"
#define MAX_LEN 10240
 

ILogServer  *g_pLogServer = NULL;

CLogServer::CLogServer()
{
	g_pLogServer = this;
	m_pWnd       = NULL;
}

void CLogServer::setWnd(CWnd *pWnd)
{
	m_pWnd = pWnd;
}

void CLogServer::log(const char * pszFormat, ...)
{
	/*
	char szBuf[MAX_LEN] = {0};

	va_list ap;
	va_start(ap, pszFormat);
	vsnprintf_s(szBuf, MAX_LEN, MAX_LEN, pszFormat, ap);
	va_end(ap);


	CTarToolDlg *pDialog   = (CTarToolDlg*)m_pWnd;
	pDialog->m_strDesc     = pDialog->m_strDesc + szBuf + "\r\n";
	pDialog->m_bChangeDesc = TRUE;
	pDialog->PostMessage(WM_UPDATE_DESC_DATA);
	//*/
	
}

void CLogServer::logLastLine(const char *lpszText, const char * pszFormat, ...)
{
	/*
	char szBuf[MAX_LEN] = {0};

	va_list ap;
	va_start(ap, pszFormat);
	vsnprintf_s(szBuf, MAX_LEN, MAX_LEN, pszFormat, ap);
	va_end(ap);

	CTarToolDlg *pDialog = (CTarToolDlg*)m_pWnd;
	pDialog->m_strDesc = lpszText;
	pDialog->m_strDesc = pDialog->m_strDesc + szBuf + "\r\n";
	pDialog->m_bChangeDesc = TRUE;
	pDialog->PostMessage(WM_UPDATE_DESC_DATA);
	//*/
}

