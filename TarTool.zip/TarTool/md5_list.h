#pragma once

#include <string>
 
class CMD5List
{
public:
	CMD5List();
	~CMD5List();
	bool initialize(const char * lpszResPath, const char *lpszSavedMD5File);
	void finialize();

	void saveMD5List();
	void saveMD5List(const char * lpPath);
private:
	

	FILE		*m_pSavedMD5File;
	std::string  m_strResPath;

	void		*m_pBuffer;
	int			 m_nBufferSize;
};