#include "stdafx.h"
#include "resource.h"
#include "TarToolDlg.h"
#include <iostream>
#include <vector>
#include <string>
#include <map>
#include "windows.h"
#include "pack_logic.h"
#include "md5.h"
#include "crc32.h"
#include "helper.h"
#include "zip.h"
#include "ILog.h"


CPackLogic::CPackLogic()
{

}

CPackLogic::~CPackLogic()
{

}

void CPackLogic::getPackSign(CPackSign &rPackSign, const char *lpszPath, const char *lpszFile)
{
	std::string strFileName = lpszPath;
	strFileName = strFileName + lpszFile;
	FILE *fp = fopen(strFileName.c_str(), "rb");

	if (fp != NULL)
	{
		while (!feof(fp))
		{
			char szFileName[1024] = {0};
			fgets(szFileName, 1023, fp);

			std::vector<std::string> strString;
			split_str_by_char(szFileName, ":", strString, true);

			if (strString.size() >= 3)
			{
				rPackSign.mapCRC[strString[0]] = strString[1];
				rPackSign.mapMD5[strString[0]] = strString[2];
			}
		}
		fclose(fp);
	}
}

bool CPackLogic::analyze(const char *lpszResPath, const char *lpszMD5Path, const char *lpszVersion, const char *lpszResPrefix, bool bNeedIncrease/* = true*/)
{
	m_strResourcePath = lpszResPath;
	m_PackList.clear();

	char szFind[MAX_PATH];
	WIN32_FIND_DATA FindFileData;
	strcpy(szFind, lpszMD5Path);
	strcat(szFind,"*.*");

	HANDLE hFind = ::FindFirstFile(szFind, &FindFileData);
	if (INVALID_HANDLE_VALUE == hFind)
	{
		return false;
	}

	// ��ȡ��ǰ�汾�ļ���Ϣ
	std::string strCurVerName = lpszResPrefix;
	strCurVerName = strCurVerName + "_" + lpszVersion + FILE_SUFFIX_NAME;
	CPackSign stCurVerPack;
	getPackSign(stCurVerPack, lpszMD5Path, strCurVerName.c_str());

	while (TRUE)
	{
		if (FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		{
		}
		else
		{
			char szMD5FileName[MAX_PATH] = {0};
			strncpy(szMD5FileName, FindFileData.cFileName, strlen(FindFileData.cFileName) - 4);

			std::string strVersionFullName = lpszResPrefix;
			strVersionFullName = strVersionFullName + "_" + lpszVersion;

			CPackData stPackData;

			if (0 == strcmp(szMD5FileName, strVersionFullName.c_str()))
			{
				stPackData.bFullPack = true;
				g_pLogServer->log("��������ȫ��ѹ�����ļ��б���%s", strVersionFullName.c_str());
				// ȫ������
				stPackData.strPackName = strVersionFullName;
				for (std::map<std::string, std::string>::iterator iter = stCurVerPack.mapMD5.begin(); iter != stCurVerPack.mapMD5.end(); ++iter)
				{
					stPackData.strFileList.push_back(iter->first);
				}
				
			}
			else
			{
				stPackData.bFullPack = false;
				bool bSuccess  = true;
				int nPrefixLen = strlen(lpszResPrefix);
				for (int i = 0; i < nPrefixLen; ++i)
				{
					if (FindFileData.cFileName[i] != lpszResPrefix[i])
					{
						bSuccess = false;
						break;
					}
				}

				if (true == bSuccess && true == bNeedIncrease)
				{
					// ��������
					CPackSign stOtherVerPack;
					getPackSign(stOtherVerPack, lpszMD5Path, FindFileData.cFileName);

					stPackData.strPackName = strVersionFullName;
					const char *lpszConnectString = szMD5FileName + strlen(lpszResPrefix);
					stPackData.strPackName = stPackData.strPackName + lpszConnectString;
					g_pLogServer->log("������������ѹ�����ļ��б���%s", stPackData.strPackName.c_str());

					for (std::map<std::string, std::string>::iterator iter = stCurVerPack.mapMD5.begin(); iter != stCurVerPack.mapMD5.end(); ++iter)
					{
						std::map<std::string, std::string>::iterator iterOther = stOtherVerPack.mapMD5.find(iter->first);
						if (iterOther == stOtherVerPack.mapMD5.end())
						{
							stPackData.strFileList.push_back(iter->first);
						}
						else
						{
							if (0 == strcmp(iter->second.c_str(), iterOther->second.c_str()))
							{
								std::map<std::string, std::string>::iterator iterCRC      = stCurVerPack.mapCRC.find(iter->first);
								std::map<std::string, std::string>::iterator iterCRCOther = stOtherVerPack.mapCRC.find(iter->first);
								if (strcmp(iterCRC->second.c_str(), iterCRCOther->second.c_str()) != 0)
								{
									stPackData.strFileList.push_back(iter->first);
								}
							}
							else
							{
								stPackData.strFileList.push_back(iter->first);
							}
						}
					}
				}
			}
			m_PackList.push_back(stPackData);
		}
		if (!FindNextFile(hFind, &FindFileData))
		{
			break;
		}
	}
	FindClose(hFind);

	return true;
}

void CPackLogic::pack(const char *lpszSavePath, CTarToolDlg *pDialog, FILE *fpSaveZipList)
{
	int nTotlePackListCount = m_PackList.size();
	int nCurPackListPos	    = 0;
	for (std::vector<CPackData>::iterator iter = m_PackList.begin(); iter != m_PackList.end(); ++iter)
	{
		if (iter->strPackName.length() <= 0)
		{
			continue;
		}
		std::string stdSaveFile = lpszSavePath;
		stdSaveFile = stdSaveFile + iter->strPackName + ".zip";

		CString strDesc;
		if (pDialog != NULL)
		{
			strDesc = pDialog->m_strDesc;
		}

		int  nCurPos     = 0;
		int  nTotleCount = iter->strFileList.size();
		HZIP hz = CreateZip(stdSaveFile.c_str(), 0);

		for (std::vector<std::string>::iterator iterFile = iter->strFileList.begin(); iterFile != iter->strFileList.end(); ++iterFile)
		{
			g_pLogServer->logLastLine(strDesc, "���ڱ����ļ���%s:(%d/%d)", stdSaveFile.c_str(), ++nCurPos, nTotleCount);
			std::string strZipFile = m_strResourcePath + "\\" + *iterFile;
			ZipAdd(hz, iterFile->c_str(), strZipFile.c_str());
		}
		CloseZip(hz);
	
		if (false == iter->bFullPack)
		{
			unsigned long ulLen = 0;
			FILE *fRead = fopen(stdSaveFile.c_str(), "rb+");
			fseek(fRead, 0, SEEK_END);
			ulLen = ftell(fRead);
			fseek(fRead, 0, SEEK_SET);
			unsigned char *pucData = new unsigned char[ulLen];
			fread(pucData, ulLen, 1, fRead);

			MD5  stMD5;
			stMD5.update((const char *)pucData, ulLen);
			stMD5.finalize();
			std::string strResult = stMD5.hexdigest();
			if (nCurPackListPos++ > 0)
			{
				fputs(",", fpSaveZipList);
			}
			fputs("\"", fpSaveZipList);
			fputs(iter->strPackName.c_str(), fpSaveZipList);
			fputs(".zip\":{\"md5\":\"", fpSaveZipList);
			fputs(strResult.c_str(), fpSaveZipList);
			fputs("\",\"compressed\":true}", fpSaveZipList);
			

			delete[] pucData;
			fclose(fRead);
		}
	}
}
