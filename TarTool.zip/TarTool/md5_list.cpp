#include "stdafx.h"
#include <iostream>
#include <vector>
#include <string>
#include <map>
#include "windows.h"
#include "md5_list.h"
#include "md5.h"
#include "crc32.h"
#include "ILog.h"

CMD5List::CMD5List()
{
	m_pSavedMD5File = NULL;
	m_pBuffer		= 0;
	m_nBufferSize   = 0;
}

CMD5List::~CMD5List()
{
	finialize();
}

bool CMD5List::initialize(const char * lpszResPath, const char *lpszSavedMD5File)
{
	m_strResPath    = lpszResPath;
	m_strResPath    = m_strResPath + "\\";
	m_pSavedMD5File = fopen(lpszSavedMD5File, "wb+");

	g_pLogServer->log("��������%s", lpszSavedMD5File);
	return m_pSavedMD5File != NULL;
}

void CMD5List::finialize()
{
	if (m_pSavedMD5File != NULL)
	{
		fclose(m_pSavedMD5File);
		m_pSavedMD5File = NULL;
	}
	if (m_pBuffer != NULL)
	{
		delete [] m_pBuffer;
		m_pBuffer     = 0;
		m_nBufferSize = 0;
	}
}

void CMD5List::saveMD5List()
{
	saveMD5List(m_strResPath.c_str());
}

void CMD5List::saveMD5List(const char * lpPath)
{
	char szFind[MAX_PATH];
	WIN32_FIND_DATA FindFileData;
	strcpy(szFind,lpPath);
	strcat(szFind,"*.*");

	HANDLE hFind = ::FindFirstFile(szFind, &FindFileData);
	if(INVALID_HANDLE_VALUE == hFind)
	{
		return;
	}
	int nResPathLen = m_strResPath.length();
	while(TRUE)
	{
		if(FindFileData.dwFileAttributes &FILE_ATTRIBUTE_DIRECTORY)
		{
			if(FindFileData.cFileName[0]!='.' && strcmp(FindFileData.cFileName, "Classes") != 0)
			{
				char szFile[MAX_PATH] = {0};
				strcpy(szFile, lpPath);
				strcat(szFile, "");
				strcat(szFile, FindFileData.cFileName);
				strcat(szFile, "\\");

				saveMD5List(szFile);
				g_pLogServer->log("������Ŀ¼%s���", FindFileData.cFileName);
			}
		}
		else
		{
			std::string strFile = lpPath;
			strFile = strFile + FindFileData.cFileName;

			FILE *fRead = fopen(strFile.c_str(), "rb+");
			int nLen = 0;
			if (fRead != NULL)
			{
				fseek(fRead, 0, SEEK_END);
				nLen = ftell(fRead);
				fseek(fRead, 0, SEEK_SET);
			}

			if (nLen > m_nBufferSize)
			{
				if (m_pBuffer != NULL)
				{
					delete [] m_pBuffer;
					m_pBuffer = NULL;
				}
				m_pBuffer = new unsigned char [nLen];
				m_nBufferSize = nLen;
			}

			void *pData = m_pBuffer;
			if (fRead != NULL)
			{
				fread(pData, nLen, 1, fRead);
			}

			MD5  stMD5;
			stMD5.update((const char *)pData, nLen);
			stMD5.finalize();
			std::string strResult = stMD5.hexdigest();
			fputs(strFile.c_str() + nResPathLen, m_pSavedMD5File);
			fputs(":", m_pSavedMD5File);
			// crc32
			unsigned int unCRC32 = crc32(0, pData, nLen);
			char szLen[128] = {0};
			_snprintf(szLen, 127, "%x", unCRC32);
			fputs(szLen, m_pSavedMD5File);
			// md5
			fputs(":", m_pSavedMD5File);
			fputs(strResult.c_str(), m_pSavedMD5File);
			fputs("\n", m_pSavedMD5File);
			
			if (fRead != NULL)
			{
				fclose(fRead);
			}
		}
		if(!FindNextFile(hFind,&FindFileData))
		{
			break;
		}
	}
	FindClose(hFind);
}



