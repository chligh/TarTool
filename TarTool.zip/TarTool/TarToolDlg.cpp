 
// TarToolDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TarTool.h"
#include "TarToolDlg.h"
#include "afxdialogex.h"
#include "md5_list.h"
#include "pack_logic.h"
#include "simple_encode.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CTarToolDlg dialog
CTarToolDlg::CTarToolDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CTarToolDlg::IDD, pParent)
{
	char pBuf[MAX_PATH] = {0};
	GetCurrentDirectory(MAX_PATH, pBuf);

	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_strVersion = _T("");
	m_strPath = pBuf;
	m_strPath = m_strPath + "\\client";
	m_strDesc = _T("");
	m_strResPrefix = _T("res");
	m_bChangeDesc  = FALSE;
}

void CTarToolDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_VER, m_strVersion);
	DDX_Text(pDX, IDC_EDIT_PATH, m_strPath);
	DDX_Text(pDX, IDC_EDIT_DESC, m_strDesc);
	DDX_Text(pDX, IDC_EDIT_RES, m_strResPrefix);
	DDX_Control(pDX, IDC_BUTTON1, m_pathBtn);
	DDX_Control(pDX, IDOK, m_btnPack);
	DDX_Control(pDX, IDC_EDIT_DESC, m_editDesc);
}

BEGIN_MESSAGE_MAP(CTarToolDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, &CTarToolDlg::OnBnClickedButton1)
	ON_MESSAGE(WM_UPDATE_DESC_DATA, &CTarToolDlg::OnUpdateDescData)
	ON_MESSAGE(WM_TAR_FINISH, &CTarToolDlg::OnTarFinish)
	ON_BN_CLICKED(IDC_BUTTON2, &CTarToolDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDOK, &CTarToolDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_BUTTON3, &CTarToolDlg::OnBnClickedButton3)
END_MESSAGE_MAP()


// CTarToolDlg message handlers

BOOL CTarToolDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	m_LogServer.setWnd(this);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTarToolDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTarToolDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

// does the directory exist?
BOOL DirectoryExist(CString Path)
{
	WIN32_FIND_DATA fd;
	BOOL ret = FALSE;
	HANDLE hFind = FindFirstFile(Path, &fd);
	if ((hFind != INVALID_HANDLE_VALUE) && (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
	{  //exist
		ret = TRUE;    
	}
	FindClose(hFind);
	return ret;
}

void CTarToolDlg::OnBnClickedButton1()
{
	UpdateData();
	CFolderPickerDialog fd(NULL, 0, this, 0);
	int ret = fd.DoModal();
	if (IDOK == ret)
	{
		m_strPath = fd.GetFolderPath();
		UpdateData(FALSE);
	}
}

bool g_bNeedIncrease = true;
DWORD WINAPI ThreadProc(LPVOID lpParameter)  
{ 
	CTarToolDlg *pThis = (CTarToolDlg*)lpParameter;
	char szRootPath[MAX_PATH] = {0};
	GetCurrentDirectory(MAX_PATH, szRootPath);
	CString strRoot = szRootPath;
	CString strCurVersion = strRoot + "\\md5\\" + pThis->m_strResPrefix + "_" + pThis->m_strVersion + FILE_SUFFIX_NAME;

	// start 
	CMD5List stMD5List;
	stMD5List.initialize(pThis->m_strPath, strCurVersion);
	stMD5List.saveMD5List();
	stMD5List.finialize();

	CPackLogic stLogic;
	CString strMD5Path = strRoot + "\\md5\\";
	stLogic.analyze(pThis->m_strPath, strMD5Path, pThis->m_strVersion, pThis->m_strResPrefix, g_bNeedIncrease);
	CString strZipPath = strRoot + "\\zip\\";

	CString strMD5List = strRoot + "\\server\\config_md5.txt";
	FILE *fp = fopen(strMD5List, "wb+");
	fputs("{", fp);
	stLogic.pack(strZipPath, pThis, fp);
	fputs("}", fp);
	fclose(fp);

	g_pLogServer->log("finish!");
	pThis->PostMessage(WM_TAR_FINISH);
	return true;
}

void EnsureDirectory(const TCHAR *rootdir, const TCHAR *dir);


void CTarToolDlg::ProcessTar()
{
	UpdateData();

	if (m_strVersion.GetLength() <= 0)
	{
		AfxMessageBox("Verson could not be empty!");
		return;
	}

	if (FALSE == DirectoryExist(m_strPath))
	{
		AfxMessageBox("��Դ�޷��ҵ�����ȷ����Դ·���Ƿ���ȷ��");
		return;
	}

	char szRootPath[MAX_PATH] = {0};
	GetCurrentDirectory(MAX_PATH, szRootPath);
	CString strRoot       = szRootPath;
	EnsureDirectory(szRootPath, "\\md5");
	EnsureDirectory(szRootPath, "\\zip");
	EnsureDirectory(szRootPath, "\\server");

	CString strCurVersion = strRoot + "\\md5\\" + m_strResPrefix + "_" + m_strVersion + FILE_SUFFIX_NAME;
	FILE *fp = fopen(strCurVersion, "rb+");
	if (fp != NULL)
	{
		fclose(fp);
		// ѯ���Ƿ񸲸�
		if (IDYES != AfxMessageBox("�Ƿ񸲸Ǹð汾�����б���" , MB_YESNO))
		{
			return;
		}
	}

	m_btnPack.EnableWindow(FALSE);
	m_pathBtn.EnableWindow(FALSE);

	DWORD dwID;  
	HANDLE hThread;  
	hThread = CreateThread(0,0,ThreadProc,this,0,&dwID); 
}

void CTarToolDlg::OnBnClickedOk()
{
	UpdateData();
	/*
	// ����
	const char *lpszResPrefix = m_strResPrefix;
	if (0 == strcmp(lpszResPrefix, "cfg"))
	{
		char szRootPath[MAX_PATH] = {0};
		GetCurrentDirectory(MAX_PATH, szRootPath);

		EnsureDirectory(szRootPath, "\\clientz");

		CString strSrcPath = szRootPath;
		strSrcPath = strSrcPath + "\\client\\";
		CString strDstPath = szRootPath;
		strDstPath = strDstPath + "\\clientz\\";

		CSimpleEncode stEncode;
		stEncode.initialize(strSrcPath, strDstPath);
	}*/

	g_bNeedIncrease = false;
	ProcessTar();
}

afx_msg LRESULT CTarToolDlg::OnUpdateDescData(WPARAM wParam, LPARAM lParam)
{
	if (TRUE == m_bChangeDesc)
	{
		m_bChangeDesc = FALSE;
		UpdateData(FALSE);
		m_editDesc.LineScroll(m_editDesc.GetLineCount());
	}
	return 0;
}


afx_msg LRESULT CTarToolDlg::OnTarFinish(WPARAM wParam, LPARAM lParam)
{
	UpdateData(FALSE);
	m_editDesc.LineScroll(m_editDesc.GetLineCount());

	m_btnPack.EnableWindow(TRUE);
	m_pathBtn.EnableWindow(TRUE);
	return 0;
}


void CTarToolDlg::OnBnClickedButton2()
{
	g_bNeedIncrease = true;
	ProcessTar();
}


void CTarToolDlg::OnBnClickedButton3()
{
	UpdateData();
	if (FALSE == DirectoryExist(m_strPath))
	{
		AfxMessageBox("��Դ�޷��ҵ�����ȷ����Դ·���Ƿ���ȷ��");
		return;
	}

	CSimpleEncode stEncode;
	CString strPath = m_strPath + "\\";
	stEncode.decodeFile(strPath);
	g_pLogServer->log("������ϣ��ļ�����ڣ�%s", strPath);
	UpdateData(FALSE);
}
