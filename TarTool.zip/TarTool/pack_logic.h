#pragma once
 
#include <string>
#include <vector>
#include <map>

class CPackData
{
public:
	std::string					strPackName;			//����(1.1.2_1.1.5)
	std::vector<std::string>	strFileList;			//�ļ��б�
	bool					    bFullPack;
};

class CPackSign
{
public:
	std::map<std::string, std::string>  mapMD5;
	std::map<std::string, std::string>  mapCRC;
};


#define FILE_SUFFIX_NAME  ".md5"

class CPackLogic
{
public:
	CPackLogic();
	~CPackLogic();
	
	bool analyze(const char *lpszResPath, const char *lpszMD5Path, const char *lpszVersion, const char *lpszResPrefix, bool bNeedIncrease = true);
	void pack(const char *lpszSavePath, CTarToolDlg *pDialog, FILE *fpSaveZipList);

private:
	void getPackSign(CPackSign &rPackSign, const char *lpszPath, const char *lpszFile);

	std::vector<CPackData>		m_PackList;
	std::string					m_strResourcePath;
};
