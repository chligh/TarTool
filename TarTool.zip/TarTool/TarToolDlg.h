 
// TarToolDlg.h : header file
//

#pragma once
#include "ILog.h"

// CTarToolDlg dialog
class CTarToolDlg : public CDialogEx
{
// Construction
public:
	CTarToolDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_TARTOOL_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
public:
	CString m_strVersion;
	CString m_strPath;
	CString m_strDesc;
	CString m_strResPrefix;
	BOOL	m_bChangeDesc;
protected:
	HICON m_hIcon;
	CLogServer	m_LogServer;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedButton1();
protected:
	void ProcessTar();


	
public:
	CButton m_pathBtn;
	CButton m_btnPack;
protected:
	afx_msg LRESULT OnUpdateDescData(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnTarFinish(WPARAM wParam, LPARAM lParam);
public:
	CEdit m_editDesc;
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
};
