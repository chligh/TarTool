 #pragma once

#include <string>

class CSimpleEncode
{
public:
	CSimpleEncode();
	~CSimpleEncode();
	bool initialize(const char * lpszResPath, const char *lpszSavedPath);
	void decodeFile(const char * lpszResPath);
private:

};